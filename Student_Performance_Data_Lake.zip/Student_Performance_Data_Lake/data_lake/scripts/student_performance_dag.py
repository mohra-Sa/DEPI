# student_performance_dag.py
from airflow import DAG
from airflow.operators.bash import BashOperator
from datetime import datetime
from datetime import timedelta

# ----------------------------------------------------
# 1. تحديد الإعدادات الأساسية لـ DAG (Metadata)
# ----------------------------------------------------

default_args = {
    'owner': 'data_engineer',
    'start_date': datetime(2025, 1, 1), # تاريخ بدء التشغيل
    'email_on_failure': True,
    'email_on_retry': False,
    'retries': 1,
    'retry_delay': timedelta(minutes=5),
}

# ----------------------------------------------------
# 2. تعريف مخطط Airflow (DAG)
# ----------------------------------------------------

with DAG(
    dag_id='student_performance_data_lake_pipeline',
    default_args=default_args,
    description='Pipeline for moving student data from Raw to Curated Zones',
    schedule_interval='@daily',  # الجدولة: تشغيل يومي
    catchup=False,
    tags=['data_lake', 'student_data'],
) as dag:

# ----------------------------------------------------
# 3. تعريف المهام (Tasks)
# ----------------------------------------------------

    # المهمة 1: تنفيذ سكربت المعالجة
    # نستخدم BashOperator لتشغيل سكربت Python مباشرة
    raw_to_processed_task = BashOperator(
        task_id='raw_to_processed_and_dqc',
        bash_command='python /path/to/your/project/scripts/1_process_data.py',
        dag=dag,
    )

    # المهمة 2: تنفيذ سكربت التنسيق والتجميع
    processed_to_curated_task = BashOperator(
        task_id='processed_to_curated_aggregation',
        bash_command='python /path/to/your/project/scripts/curate_data.py',
        dag=dag,
    )

# ----------------------------------------------------
# 4. تحديد التبعيات (Dependencies)
# ----------------------------------------------------

    # تحديد الترتيب: المهمة الأولى يجب أن تكتمل بنجاح قبل أن تبدأ المهمة الثانية.
    # الترتيب: (raw_to_processed_task) يسبق (processed_to_curated_task)
    raw_to_processed_task >> processed_to_curated_task