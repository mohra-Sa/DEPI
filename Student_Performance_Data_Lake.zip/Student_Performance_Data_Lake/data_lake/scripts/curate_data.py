# -*- coding: utf-8 -*-
"""
scripts/curate_data.py

المرحلة الثانية (Stage 2): قراءة البيانات المعالجة وإنشاء جداول تحليلية (Curated Zone).
"""
import os
import pandas as pd
import glob
import sys # مكتبة لإدارة الخروج من السكريبت في حالة الخطأ

# 📍 تحديد المسارات الثابتة لمناطق بحيرة البيانات (Zones)
PROCESSED_ZONE_PATH = 'data_lake/processed_zone'
CURATED_ZONE_PATH = 'data_lake/curated_zone'
# نمط الملف الذي نبحث عنه في Processed Zone
PROCESSED_FILE_PATTERN = os.path.join(PROCESSED_ZONE_PATH, 'students_processed.parquet')

print("--- المرحلة الثانية: تنسيق البيانات (Data Curation) ---")

# ----------------- الوظيفة 1: تحميل البيانات -----------------
def load_processed_data(file_pattern):
    """
    يقوم بتحميل ملف Parquet المُعالَج من طبقة Processed Zone.
    """
    try:
        # 🔍 استخدام glob للبحث عن الملف بشكل ديناميكي (بدلاً من تحديد اسم ملف محدد بتاريخ معين)
        files = glob.glob(file_pattern)
        if not files:
            print(f" ❌ خطأ: لم يتم العثور على ملف Parquet في المسار: {PROCESSED_ZONE_PATH}")
            # الخروج برمز خطأ (1) لتنبيه Airflow بفشل المهمة
            sys.exit(1)
        
        # 💾 تحميل الملف
        df = pd.read_parquet(files[0])
        print(f" ✅ تم تحميل {len(df)} صفاً من ملف {os.path.basename(files[0])}")
        return df
    except Exception as e:
        print(f" ❌ فشل في تحميل البيانات المعالجة. التفاصيل: {e}")
        sys.exit(1)

# ----------------- الوظيفة 2: منطق التجميع (Aggregation) -----------------
def curate_data(df):
    """
    ينفذ عمليات التجميع المطلوبة (Aggregation) لإنشاء الجداول المنسّقة.
    """
    print("\n[1/2] إنشاء جدول 'متوسط الدرجات حسب المادة'...")
    # 1. التجميع الأول: متوسط الدرجات لكل مادة
    avg_score_per_subject = df.groupby('subject_name')['score'].mean().reset_index()
    avg_score_per_subject.rename(columns={'score': 'average_score'}, inplace=True)
    avg_score_per_subject['average_score'] = avg_score_per_subject['average_score'].round(2)
    
    print("\n[2/2] إنشاء جدول 'الأداء حسب المدينة'...")
    # 2. التجميع الثاني: مقاييس الأداء حسب المدينة
    performance_by_city = df.groupby('city').agg(
        average_attendance_rate=('attendance_rate', 'mean'),
        average_gpa=('previous_gpa', 'mean'),
        student_count=('student_id', 'nunique')
    ).reset_index()
    
    performance_by_city['average_attendance_rate'] = performance_by_city['average_attendance_rate'].round(2)
    performance_by_city['average_gpa'] = performance_by_city['average_gpa'].round(2)
    
    # 🔄 إرجاع الجداول التحليلية الناتجة
    return avg_score_per_subject, performance_by_city

# ----------------- الوظيفة 3: حفظ البيانات -----------------
def save_curated_data(df, filename):
    """
    حفظ DataFrame في ملف CSV داخل Curated Zone.
    """
    output_path = os.path.join(CURATED_ZONE_PATH, filename)
    df.to_csv(output_path, index=False)
    print(f" ✅ تم حفظ البيانات بنجاح في: {output_path}")

# ----------------- 🎯 نقطة البداية للتشغيل (The Main Block) -----------------
if __name__ == "__main__":
    # 🌟 هذا الجزء هو الذي يتم تنفيذه فقط عند تشغيل الملف مباشرةً من سطر الأوامر.
    
    # 1. التأكد من وجود مجلد Curated Zone قبل البدء
    os.makedirs(CURATED_ZONE_PATH, exist_ok=True)
    print(f" 📂 تم التحقق من مسار Curated Zone: {CURATED_ZONE_PATH}")

    # 2. استدعاء الوظائف بالترتيب
    
    # 2.1. تحميل البيانات
    processed_df = load_processed_data(PROCESSED_FILE_PATTERN)
    
    # 2.2. تنسيق البيانات (التجميع)
    avg_subject_df, city_perf_df = curate_data(processed_df)
    
    # 2.3. حفظ النتائج
    print("\n[3/3] حفظ النتائج المُجمَّعة في Curated Zone...")
    save_curated_data(avg_subject_df, 'avg_score_per_subject.csv')
    save_curated_data(city_perf_df, 'performance_by_city.csv')
    
    print("\n🎉 تم اكتمال تنسيق البيانات بنجاح! (Success)")