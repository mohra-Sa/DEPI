# 🎓 Student Performance Analysis: Data Lake Project

هذا المشروع هو تطبيق عملي لبناء **خط أنابيب بيانات (Data Pipeline)** باستخدام نموذج **بحيرة بيانات (Data Lake)** مصغرة.  
تم تطويره بهدف إظهار القدرة على تطبيق مفاهيم **هندسة البيانات الحديثة**، مع التركيز على **جودة البيانات** و **مرونة الكود**.

---

## 🏛️ بنية بحيرة البيانات المُحسّنة (Data Lake Architecture)

يعتمد المشروع على البنية الثلاثية الأساسية:

| الطبقة (Zone)                        | الغرض                                                   | الصيغة التقنية | الميزة الاحترافية المضافة                                                                                       |
|---------------------------------------|---------------------------------------------------------|---------------|--------------------------------------------------------------------------------------------------------------|
|  **Raw Zone (الخام)**              | تخزين البيانات الأولية كما وردت من المصدر.               | CSV           |  تنظيم بالتاريخ (Versioning): يتم تقسيم البيانات آليًا حسب تاريخ الإدخال (`/YYYYMMDD/`) لتسهيل التتبع. |
|  **Processed Zone (المعالَجة)**     | بيانات نظيفة وموحدة وجاهزة للتحليل.                     | Parquet       |  فحص جودة البيانات (DQC): تطبيق قواعد صارمة (مثل التأكد من الدرجات ضمن [0–100] وإزالة التكرارات).       |
|  **Curated Zone (المنسّقة)**        | جداول تجميعية ونتائج نهائية جاهزة للاستخدام المباشر.   | CSV           |  مرونة الكود (Robustness): تحميل الملفات ديناميكيًا باستخدام `glob` بدون الاعتماد على اسم ثابت.         |

> ✨ تم تصميم البنية لتكون **قابلة للتطوير** و **سهلة الجدولة والأتمتة** في بيئات الإنتاج.

---

## 📁 هيكل المشروع (Project Structure)

```
.
├── .gitignore
├── README.md
├── data_lake/
│   ├── curated_zone/
│   │   ├── avg_score_per_subject.csv
│   │   └── performance_by_city.csv
│   ├── processed_zone/
│   │   └── students_processed.parquet
│   └── raw_zone/
│       └── student_performance/
│           └── [YYYYMMDD]/
│               └── student_performance_dashboard.csv
├── notebooks/
│   ├── 1_Data_Ingestion_and_Processing.ipynb
│   └── 2_Data_Curation_and_Analysis.ipynb
└── scripts/
    ├── 1_process_data.py              # تنفيذ Raw → Processed + DQC
    ├── curate_data.py                 # تنفيذ Processed → Curated + Aggregation
    └── student_performance_dag.py     # خطة أتمتة Airflow
```

---

## 🚀 كيفية تشغيل المشروع (How to Run)

### 1. تجهيز البيئة

- تأكد من وجود ملف البيانات الخام `student_performance_dashboard.csv` في المجلد الرئيسي.  
- تأكد من تثبيت المكتبات المطلوبة:

```bash
pip install pandas pyarrow
```

---

### 2. المرحلة الأولى: المعالجة والتحقق من الجودة (DQC)

🔹 هذه المرحلة تنقل البيانات من **Raw Zone** إلى **Processed Zone** بعد تنظيفها وفحص الجودة.

```bash
python scripts/1_process_data.py
```

📦 **الناتج:**  
`data_lake/processed_zone/students_processed.parquet`

---

### 3. المرحلة الثانية: التنسيق والتجميع (Curation & Aggregation)

🔹 هذه المرحلة تستخدم البيانات المُعالجة لإنشاء جداول تحليلية جاهزة للاستخدام.

```bash
python scripts/curate_data.py
```

📊 **الناتج:**  
- `data_lake/curated_zone/avg_score_per_subject.csv`  
- `data_lake/curated_zone/performance_by_city.csv`

---

## 🔁 الجدولة والأتمتة (Orchestration Plan)

لضمان التشغيل المنتظم للمشروع في بيئة إنتاج، يتم استخدام **Apache Airflow** لإنشاء DAG كما هو موضح في:
`student_performance_dag.py`

- ⏳ **المرحلة الأولى:** `1_process_data.py`  
- 🪄 **المرحلة الثانية:** `curate_data.py`  
- 🔗 **الاعتماد:** لا يتم تشغيل المرحلة الثانية إلا بعد نجاح المرحلة الأولى.

🎯 **الهدف:**  
ضمان أن التقارير النهائية يتم إنشاؤها فقط بعد اجتياز جميع فحوصات جودة البيانات (DQC).

---

## 📝 ملاحظات إضافية

- يمكن تشغيل المشروع أيضًا داخل **Google Colab** بخلايا منفصلة تم تجهيزها لسهولة التنفيذ.  
- كل مرحلة تحتوي على رسائل طباعة واضحة لتتبع مراحل التشغيل.  
- الكود مصمم ليكون مرنًا، قابلًا للتطوير، ويمكن دمجه مع أدوات BI مثل Google Sheets أو Looker Studio.
