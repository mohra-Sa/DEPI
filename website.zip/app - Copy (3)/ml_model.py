import pandas as pd
from sklearn.preprocessing import StandardScaler, LabelEncoder
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score, classification_report, confusion_matrix
import joblib
import warnings
import numpy as np
warnings.filterwarnings('ignore')

print("🚀 Starting INTELLIGENT model training...")

# Load data
df = pd.read_csv(r"C:\Users\DUBAI STORE\Downloads\clean_student_performance_final (2).csv")
print(f"✅ Loaded {df.shape[0]} rows, {df.shape[1]} columns")

# Check target distribution
print("\n📊 Target Distribution:")
print(df['final_state'].value_counts())

# Clean data - drop unnecessary columns
cols_to_drop = ["student_id", "name", "grade_level", "description", "country", 
                "teacher_name", "internet_access", "extracurricular_activities",
                "scholarship_status", "tutoring"]
df = df.drop(columns=[col for col in cols_to_drop if col in df.columns])

# Handle month
if 'month' in df.columns:
    df["month"] = pd.to_datetime(df["month"], errors='coerce')
    df["month"] = df["month"].dt.month.fillna(1).astype(int)

# Fill missing values intelligently
df = df.fillna({
    'age': df['age'].median(),
    'score': df['score'].median(),
    'sleep_hours': 7,
    'study_hours': 3,
    'attendance_rate': 80,
    'homework_completion_rate': 80,
    'family_size': 4,
    'previous_gpa': 3.0,
    'exam_attempts': 1,
    'teacher_experience_years': 5,
    'parent_income': 50000,
    'feedback_rating': 4,
    'efficiency': 75,
    'hours_per_week': 10
})

print("✅ Data cleaned")

# Store original categorical mappings for reference
original_mappings = {
    "gender": {"female": 0, "male": 1},
    "difficulty_level": {"easy": 0, "medium": 1, "hard": 2},
    "parent_education": {"none": 0, "high school": 1, "college": 2, "postgrad": 3},
    "health_condition": {"normal": 0, "mild illness": 1, "chronic": 2},
    "performance_level": {"weak": 0, "average": 1, "good": 2, "excellent": 3}
}

# Apply mappings
for col, mapping in original_mappings.items():
    if col in df.columns:
        df[col] = df[col].map(mapping).fillna(0)

print("✅ Categorical columns encoded")

# Encode target variable
le = LabelEncoder()
df["final_state"] = le.fit_transform(df["final_state"])
print(f"✅ Target classes: {', '.join(le.classes_)}")

# ============ CRITICAL FIX: Target Encoding ============
# We WON'T use target encoding - it causes prediction bias!
# Instead, we'll use simple label encoding or one-hot encoding

# For categorical columns with few categories - use label encoding
label_encode_cols = ["subject_name", "city", "free_time_activity", "school_transport"]
category_mappings = {}

for col in label_encode_cols:
    if col in df.columns:
        # Create label encoding mapping
        unique_vals = df[col].unique()
        mapping = {val: idx for idx, val in enumerate(unique_vals)}
        category_mappings[col] = mapping
        df[col] = df[col].map(mapping).fillna(len(mapping))  # Unknown = new category

print("✅ Label encoding applied to categorical columns")

# For admission_year - normalize it
if 'admission_year' in df.columns:
    year_min = df['admission_year'].min()
    year_max = df['admission_year'].max()
    category_mappings['admission_year'] = {'min': year_min, 'max': year_max}
    df['admission_year'] = (df['admission_year'] - year_min) / (year_max - year_min + 1)

# Save category mappings
joblib.dump(category_mappings, 'category_mappings.pkl')
print(f"✅ Saved category mappings for {len(category_mappings)} columns")

# Feature Engineering - Create interaction features
if 'study_hours' in df.columns and 'attendance_rate' in df.columns:
    df['study_attendance_interaction'] = df['study_hours'] * df['attendance_rate']
    
if 'previous_gpa' in df.columns and 'score' in df.columns:
    df['gpa_score_interaction'] = df['previous_gpa'] * df['score']

# Prepare features for scaling
feature_cols = [col for col in df.columns if col != 'final_state']

# Normalize features using StandardScaler
scaler = StandardScaler()
df[feature_cols] = scaler.fit_transform(df[feature_cols])

print(f"✅ Scaled {len(feature_cols)} features using StandardScaler")

# Split data with stratification
x = df.drop(columns=["final_state"])
y = df["final_state"]

x_train, x_test, y_train, y_test = train_test_split(
    x, y, test_size=0.2, random_state=42, stratify=y
)

print(f"✅ Train set: {x_train.shape[0]} samples")
print(f"✅ Test set: {x_test.shape[0]} samples")
print(f"✅ Class distribution in training:")
for cls in le.classes_:
    count = (y_train == le.transform([cls])[0]).sum()
    pct = count / len(y_train) * 100
    print(f"   {cls}: {count} ({pct:.1f}%)")

# Train model with optimized hyperparameters
print("\n⏳ Training OPTIMIZED Random Forest model...")
model = RandomForestClassifier(
    n_estimators=500,          
    max_depth=20,              
    min_samples_split=5,       
    min_samples_leaf=2,        
    max_features='sqrt',       
    random_state=42,
    class_weight="balanced",   
    n_jobs=-1,
    bootstrap=True,
    oob_score=True            
)
model.fit(x_train, y_train)

# Evaluate
y_pred = model.predict(x_test)
y_pred_proba = model.predict_proba(x_test)

acc = accuracy_score(y_test, y_pred)
oob_score = model.oob_score_

print("\n" + "="*60)
print(f"🎯 Model Accuracy: {acc*100:.2f}%")
print(f"🎯 OOB Score: {oob_score*100:.2f}%")
print("="*60)

print("\n📊 Classification Report:")
print(classification_report(y_test, y_pred, target_names=le.classes_))

print("\n📊 Confusion Matrix:")
cm = confusion_matrix(y_test, y_pred)
print(cm)
print(f"\nCorrect Pass predictions: {cm[1,1]}")
print(f"Correct Fail predictions: {cm[0,0]}")

# Feature importance
feature_importance = pd.DataFrame({
    'feature': x.columns,
    'importance': model.feature_importances_
}).sort_values('importance', ascending=False)

print("\n🔍 Top 15 Most Important Features:")
print(feature_importance.head(15))

# Test with a good student profile
print("\n" + "="*60)
print("🧪 TESTING WITH EXCELLENT STUDENT PROFILE")
print("="*60)

test_data = {
    'age': 18,
    'gender': 1,  # male
    'subject_name': category_mappings['subject_name'].get('math', 0),
    'hours_per_week': 40,
    'score': 95,
    'sleep_hours': 8,
    'study_hours': 6,
    'attendance_rate': 95,
    'homework_completion_rate': 95,
    'family_size': 4,
    'previous_gpa': 3.8,
    'city': category_mappings['city'].get('cairo', 0),
    'exam_attempts': 1,
    'teacher_experience_years': 10,
    'parent_income': 80000,
    'parent_education': 2,  # college
    'feedback_rating': 4.5,
    'efficiency': 90,
    'difficulty_level': 1,  # medium
    'health_condition': 0,  # normal
    'performance_level': 3,  # excellent
    'admission_year': (2023 - category_mappings['admission_year']['min']) / (category_mappings['admission_year']['max'] - category_mappings['admission_year']['min'] + 1),
    'free_time_activity': category_mappings['free_time_activity'].get('sports', 0),
    'school_transport': category_mappings['school_transport'].get('bus', 0)
}

# Add month if exists
if 'month' in x.columns:
    test_data['month'] = 3

# Add interaction features
test_data['study_attendance_interaction'] = test_data['study_hours'] * test_data['attendance_rate']
test_data['gpa_score_interaction'] = test_data['previous_gpa'] * test_data['score']

test_df = pd.DataFrame([test_data])
test_df = test_df[feature_cols]
test_df_scaled = scaler.transform(test_df)

test_pred = model.predict(test_df_scaled)[0]
test_proba = model.predict_proba(test_df_scaled)[0]
test_result = le.inverse_transform([test_pred])[0]

print(f"\n🎓 Excellent Student Prediction: {test_result}")
print(f"📊 Probabilities: {dict(zip(le.classes_, test_proba))}")
print(f"✅ Pass Probability: {test_proba[1]*100:.1f}%")

# Save models and metadata
joblib.dump(model, 'model.pkl')
joblib.dump(le, 'encoder.pkl')
joblib.dump(scaler, 'scaler.pkl')
joblib.dump(category_mappings, 'category_mappings.pkl')
joblib.dump(original_mappings, 'original_mappings.pkl')
joblib.dump(feature_cols, 'feature_cols.pkl')

print("\n✅ All models and metadata saved successfully!")
print("📦 Files created:")
print("  - model.pkl (Random Forest)")
print("  - encoder.pkl (Label Encoder)")
print("  - scaler.pkl (Standard Scaler)")
print("  - category_mappings.pkl (Label Encoding Maps)")
print("  - original_mappings.pkl (Categorical Mappings)")
print("  - feature_cols.pkl (Feature Column Names)")

print("\n🎉 Ready to run: streamlit run app.py") 